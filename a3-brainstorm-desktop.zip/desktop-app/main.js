const { app, BrowserWindow, Menu } = require("electron");
const path = require("path");

function createWindow() {
  const win = new BrowserWindow({
    width: 480,
    height: 860,
    minWidth: 380,
    minHeight: 640,
    backgroundColor: "#1B1F3B",
    icon: path.join(__dirname, "build", "icon.png"),
    title: "A3 Brain Storm",
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      // Keep the same copy/print/right-click restrictions the web app already
      // enforces in-page (see the JS at the bottom of app.html). Electron adds
      // an OS-level layer on top via the menu below.
    },
  });

  win.loadFile("app.html");

  // Strip Electron's default menu (which normally exposes "Copy", "Print",
  // dev tools, etc.) so the desktop shell matches the app's own content
  // protections instead of undermining them.
  Menu.setApplicationMenu(null);
}

app.whenReady().then(() => {
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
