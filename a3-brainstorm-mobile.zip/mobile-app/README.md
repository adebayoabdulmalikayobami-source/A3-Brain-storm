# A3 Brain Storm — Mobile App (Android + iOS)

This folder wraps the A3 Brain Storm web app in Capacitor, so it can be built
into a real native Android app (for the Play Store) and a real native iOS
app (for the App Store) — not just a browser-installed PWA.

## Why this can't be built here

Turning this into an actual `.apk`/`.aab` (Android) or a Play Store /
App Store submission requires:
- Downloading Node packages from npm (no internet access in this sandbox)
- **Android**: Android Studio + the Android SDK installed locally
- **iOS**: a Mac with Xcode installed (Apple only allows iOS builds on macOS)

So the actual compiling has to happen on your own machine. Everything here
is the complete, ready-to-build project — this is the real work, just
missing the final "press build" step that needs those tools present.

## What's in this folder

- `www/` — the full app (same file as the web/PWA version), plus its icons,
  manifest and service worker
- `capacitor.config.json` — app ID, name, and native settings
- `package.json` — the Capacitor dependencies needed to build both platforms

## How to build it yourself

You'll need [Node.js](https://nodejs.org) (v18+) installed.

```bash
cd a3-brainstorm-mobile
npm install

# Add the native platform projects (only needed once each)
npx cap add android
npx cap add ios          # macOS only

# Whenever you change anything in www/, re-sync it into the native projects
npx cap sync

# Open the native projects to build, test on a device/emulator, and export
npx cap open android     # opens Android Studio
npx cap open ios         # opens Xcode (macOS only)
```

From Android Studio: **Build → Generate Signed Bundle / APK** produces the
`.aab` file you upload to the Google Play Console.

From Xcode: **Product → Archive** starts the process of submitting to
App Store Connect.

## Before shipping this for real

- **App icons**: `www/icon-512.png` is used as a starting point, but Android
  and iOS both expect a full set of pre-sized icons (adaptive icons for
  Android, multiple sizes for iOS). The `@capacitor/assets` tool can generate
  all of them automatically from one source image — worth running before
  your first real submission.
- **Developer accounts**: Google Play requires a one-time $25 registration;
  Apple requires a $99/year Apple Developer Program membership. Both are
  required before you can actually publish, separate from the build itself.
- **Permissions**: if you later add camera access (e.g. for the passport
  photo/receipt upload to use the device camera directly instead of the
  file picker), Android and iOS each need a short permissions declaration
  added to their native project — ask when you're ready for that.
- **Screenshot protection**: this is also the point where true screenshot
  blocking becomes possible on Android (`FLAG_SECURE`, set in the native
  Android project) — something no purely web-based version of this app
  could ever do. iOS still has no equivalent API, native or otherwise.
